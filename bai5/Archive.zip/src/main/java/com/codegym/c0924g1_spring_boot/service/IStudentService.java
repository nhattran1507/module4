package com.codegym.c0924g1_spring_boot.service;

import com.codegym.c0924g1_spring_boot.model.Student;

public interface IStudentService extends IService<Student> {

}
