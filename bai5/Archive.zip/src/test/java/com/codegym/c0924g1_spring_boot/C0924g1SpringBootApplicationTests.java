package com.codegym.c0924g1_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C0924g1SpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
