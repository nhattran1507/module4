package com.codegym.c0924g1_spring_boot.service;

import com.codegym.c0924g1_spring_boot.model.Classroom;

public interface IClassroomService extends IService<Classroom>{
}
