package com.codegym.c0924g1.entity;

public class Teacher extends Person{
}
