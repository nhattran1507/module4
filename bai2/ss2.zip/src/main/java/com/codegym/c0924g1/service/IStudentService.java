package com.codegym.c0924g1.service;

import com.codegym.c0924g1.entity.Student;

import java.util.List;

public interface IStudentService {
    List<Student> findAll();

    void save(Student student);
}
