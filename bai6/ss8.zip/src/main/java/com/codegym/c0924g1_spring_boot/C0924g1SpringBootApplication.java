package com.codegym.c0924g1_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C0924g1SpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(C0924g1SpringBootApplication.class, args);
    }

}
